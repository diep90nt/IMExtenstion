chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  var url = tabs[0].url;

  var match = url.match(/\/subscriptions\/([^/]+)\/resourceGroups\/([^/]+)\/providers\/Microsoft.Web\/sites\/([^/]+)(?:\/slots\/([^/]+))?\/appServices/);
  var subid = "";
  var appplan = "";
  var webapp = "";

  if (match) {
    subid = match[1];
    appplan = match[2];
    webapp = match[3];
  } else {
    match = url.match(/\/#view\/Microsoft_Azure_MonitoringMetrics\/Metrics.ReactView\/ResourceId\/%2Fsubscriptions%2F([^/]+)%2FresourceGroups%2F([^/]+)%2Fproviders%2FMicrosoft.Web%2Fsites%2F([^/]+)/);
    if (match) {
      subid = match[1];
      appplan = match[2];
      webapp = match[3];
    } else {
      match = url.match(/\/#view\/Microsoft_Azure_MonitoringMetrics\/Metrics.ReactView\/ResourceId\/%2Fsubscriptions%2F([^/]+)%2FresourceGroups%2F([^/]+)%2Fproviders%2FMicrosoft.Web%2Fserverfarms%2F([^/]+)/);
      if (match) {
        subid = match[1];
        appplan = match[2];
        webapp = match[3];
      }
    }
  }

  chrome.action.getBadgeText({}, function (result) {
    if (!result.includes("Bearer")) {
      alert("Please refresh the tab and go to the response time chart first to get the extension working.");
      return;
    }

    const authorizationElement = document.getElementById("authorization-value");
    const subidElement = document.getElementById("subid");
    subidElement.textContent = `Subscription ID: ${subid}`;
    const appplanElement = document.getElementById("appplan");
    appplanElement.textContent = `App Plan: ${appplan}`;
    const webappElement = document.getElementById("webapp");
    webappElement.textContent = `Web App: ${webapp}`;

    const dropdownElement = document.getElementById("machine-names");
    const replaceButton = document.getElementById("replace-button");
    const goToKuduButton = document.getElementById("go-to-kudu-button");
    const takeTrace = document.getElementById("take-trace");
    const takeDump = document.getElementById("take-dump");
    const masterScript = document.getElementById("master-script");
    const checkVersion = document.getElementById("check-version");
    const aiQuery = document.getElementById("ai-query");

    fetch(`https://management.azure.com/subscriptions/${subid}/resourceGroups/${appplan}/providers/Microsoft.Web/sites/${webapp}/instances?api-version=2020-12-01`, {
      headers: {
        'Authorization': result,
        'Content-Type': 'application/json'
      }
    })
      .then(response => response.json())
      .then(data => {
        const machineNames = data.value.map(instance => instance.properties.machineName);
        machineNames.forEach(name => {
          const option = document.createElement('option');
          option.text = name;
          dropdownElement.appendChild(option);
        });

        replaceButton.addEventListener("click", function () {
          const selectedMachineName = dropdownElement.value;
          if (selectedMachineName) {
            fetch(`https://management.azure.com/subscriptions/${subid}/resourceGroups/${appplan}/providers/Microsoft.Web/serverfarms/${webapp}/workers/${selectedMachineName}/reboot?api-version=2022-03-01`, {
              method: "POST",
              headers: {
                'Authorization': result,
                'Content-Type': 'application/json'
              }
            })
              .then(response => {
                if (response.status >= 200 && response.status < 300) {
                  alert(`Machine ${selectedMachineName} is replaced.`);
                } else {
                  response.text().then(error => {
                    alert(`Error replacing machine ${selectedMachineName}: ${error}`);
                  });
                }
              })
              .catch(error => {
                console.error('Error replacing machine:', error);
              });
          } else {
            alert("Please select a machine to replace.");
          }
        });

goToKuduButton.addEventListener("click", function () {
  const selectedMachineName = dropdownElement.value;
  if (selectedMachineName) {
    const instance = data.value.find(instance => instance.properties.machineName === selectedMachineName);
    if (instance && instance.properties.consoleUrl) {
      let kuduUrl = instance.properties.consoleUrl.replace("webssh/host", "newui/env");

      // Append the query ?hideSecrets=false properly
      if (kuduUrl.includes('?')) {
        kuduUrl += '&hideSecrets=false';
      } else {
        kuduUrl += '?hideSecrets=false';
      }

      chrome.tabs.create({ url: kuduUrl });
    } else {
      alert(`Console URL not found for machine ${selectedMachineName}`);
    }
  } else {
    alert("Please select a machine.");
  }
});

aiQuery.addEventListener("click", function () {
  const resourceUrl = `https://portal.azure.com/#@episerver.net/resource/subscriptions/${subid}/resourceGroups/${appplan}/providers/microsoft.insights/components/${webapp}/logs`;

  // Full Kusto query block to copy
  const scriptText = `//Top domain query
requests
| extend urlParts = parseurl(url)
| extend hostname = urlParts.Host
| summarize sum(itemCount) by tostring(hostname), bin(timestamp, 1m)
| render timechart

//List requests by time
requests
| where timestamp > datetime(2025-03-31T11:00:00) and timestamp < datetime(2025-03-31T12:00:00) and name !contains "bus"
| project timestamp, id, name, url, performanceBucket, resultCode, cloud_RoleInstance
| sort by timestamp asc

//Check abnormal operation
requests
| where timestamp > datetime(2024-03-25T16:00:00) and timestamp < datetime(2024-03-25T17:00:00)
| summarize sum(itemCount) by operation_Name, bin(timestamp, 1m)
| render timechart

//View operation by columnchart
requests
| where timestamp > datetime(2025-03-31T11:00:00) and timestamp < datetime(2025-03-31T12:00:00) and name !contains "bus"
| top-nested 100 of bin(timestamp, 1m) by count(),
top-nested 10 of name by sum(itemCount)
| project timestamp, name, c=aggregated_name
| order by timestamp asc
| render columnchart`;

  const tempInput = document.createElement("textarea");
  tempInput.value = scriptText;
  document.body.appendChild(tempInput);
  tempInput.select();
  document.execCommand("copy");
  document.body.removeChild(tempInput);

  chrome.tabs.create({ url: resourceUrl });
});
        
        takeTrace.addEventListener("click", function () {
  const selectedMachineName = dropdownElement.value;
  if (selectedMachineName) {
    const instance = data.value.find(instance => instance.properties.machineName === selectedMachineName);
    if (instance && instance.properties.consoleUrl) {
      const kuduUrl = instance.properties.consoleUrl.replace("webssh/host", "newui/webssh");

      // Copy the text to clipboard
      const scriptText = "curl -o script.sh https://raw.githubusercontent.com/diepnt90/getdumptrace/refs/heads/main/script.sh && chmod +x script.sh && ./script.sh --trace";
      const tempInput = document.createElement("textarea");
      tempInput.value = scriptText;
      document.body.appendChild(tempInput);
      tempInput.select();
      document.execCommand("copy");
      document.body.removeChild(tempInput);

      // Open the new tab
      chrome.tabs.create({ url: kuduUrl });
    } else {
      alert(`Console URL not found for machine ${selectedMachineName}`);
    }
  } else {
    alert("Please select a machine.");
  }
});

        takeDump.addEventListener("click", function () {
  const selectedMachineName = dropdownElement.value;
  if (selectedMachineName) {
    const instance = data.value.find(instance => instance.properties.machineName === selectedMachineName);
    if (instance && instance.properties.consoleUrl) {
      const kuduUrl = instance.properties.consoleUrl.replace("webssh/host", "newui/webssh");

      // Copy the text to clipboard
      const scriptText = "curl -o script.sh https://raw.githubusercontent.com/diepnt90/getdumptrace/refs/heads/main/script.sh && chmod +x script.sh && ./script.sh --dump";
      const tempInput = document.createElement("textarea");
      tempInput.value = scriptText;
      document.body.appendChild(tempInput);
      tempInput.select();
      document.execCommand("copy");
      document.body.removeChild(tempInput);

      // Open the new tab
      chrome.tabs.create({ url: kuduUrl });
    } else {
      alert(`Console URL not found for machine ${selectedMachineName}`);
    }
  } else {
    alert("Please select a machine.");
  }
});

                masterScript.addEventListener("click", function () {
  const selectedMachineName = dropdownElement.value;
  if (selectedMachineName) {
    const instance = data.value.find(instance => instance.properties.machineName === selectedMachineName);
    if (instance && instance.properties.consoleUrl) {
      const kuduUrl = instance.properties.consoleUrl.replace("webssh/host", "newui/webssh");

      // Copy the text to clipboard
      const scriptText = "curl -o script.sh https://raw.githubusercontent.com/diepnt90/MasterScript/refs/heads/main/script.sh && chmod +x script.sh && ./script.sh";
      const tempInput = document.createElement("textarea");
      tempInput.value = scriptText;
      document.body.appendChild(tempInput);
      tempInput.select();
      document.execCommand("copy");
      document.body.removeChild(tempInput);

      // Open the new tab
      chrome.tabs.create({ url: kuduUrl });
    } else {
      alert(`Console URL not found for machine ${selectedMachineName}`);
    }
  } else {
    alert("Please select a machine.");
  }
});

                                checkVersion.addEventListener("click", function () {
  const selectedMachineName = dropdownElement.value;
  if (selectedMachineName) {
    const instance = data.value.find(instance => instance.properties.machineName === selectedMachineName);
    if (instance && instance.properties.consoleUrl) {
      const kuduUrl = instance.properties.consoleUrl.replace("webssh/host", "newui/webssh");

      // Copy the text to clipboard
      const scriptText = "curl -o gathermodule.sh https://raw.githubusercontent.com/diepnt90/SiteAudit/refs/heads/main/gathermodule.sh && chmod +x gathermodule.sh && ./gathermodule.sh";
      const tempInput = document.createElement("textarea");
      tempInput.value = scriptText;
      document.body.appendChild(tempInput);
      tempInput.select();
      document.execCommand("copy");
      document.body.removeChild(tempInput);

      // Open the new tab
      chrome.tabs.create({ url: kuduUrl });
    } else {
      alert(`Console URL not found for machine ${selectedMachineName}`);
    }
  } else {
    alert("Please select a machine.");
  }
});

      })
      .catch(error => {
        console.error('Error fetching machine names:', error);
      });
  });
});
