chrome.webRequest.onBeforeSendHeaders.addListener(
  function(details) {
    const url = new URL(details.url);
    const domain = url.hostname;
    
    if (domain === "management.azure.com") {
      for (const header of details.requestHeaders) {
        const headerName = header.name.toLowerCase();
        if (headerName === "authorization") {
          const authorizationValue = header.value;
          chrome.action.setBadgeText({ text: authorizationValue });
          break;
        }
      }
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders"]
);
